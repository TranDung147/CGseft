package Exception;

public class DuplicateMedicalRecordException extends Exception {
    public DuplicateMedicalRecordException(String message) {
        super(message);
    }
}